package com.example.eternalrain;

import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Eternal Rain: в каждом мире, где вообще бывает погода, всегда идёт дождь.
 */
@Mod(EternalRain.MODID)
public class EternalRain {
    public static final String MODID = "eternalrain";

    /** Длительность "заказанного" дождя в тиках (~14 часов), потом обновляем. */
    private static final int RAIN_DURATION = 1_000_000;

    public EternalRain() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) {
            return;
        }

        // Погода есть только в мирах с небом и без потолка (Верхний мир и похожие),
        // в Незере и Энде дождя не бывает.
        if (!level.dimensionType().hasSkyLight() || level.dimensionType().hasCeiling()) {
            return;
        }

        // Проверяем раз в секунду; обновляем срок дождя примерно раз в 5 минут.
        long time = level.getGameTime();
        if (time % 20 != 0) {
            return;
        }

        boolean needFix = !level.isRaining() || level.isThundering();
        if (needFix || time % 6000 == 0) {
            // clearTime=0, weatherTime=RAIN_DURATION, raining=true, thundering=false
            level.setWeatherParameters(0, RAIN_DURATION, true, false);
        }
    }
}
